package com.google.appengine.api.labs.modules;

/**
 * Exception thrown when the given instance value is not valid.
 *
 */
@Deprecated
public class InvalidInstanceException extends ModulesException {

  InvalidInstanceException(String detail) {
    super(detail);
  }
}
