// Copyright 2010 Google Inc. All rights reserved.
package com.google.appengine.api.taskqueue;

/**
 * Queue operation failure caused by Datastore exception
 *
 */
public class TransactionalTaskException extends RuntimeException {
}
