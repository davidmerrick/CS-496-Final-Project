package com.google.appengine.api.labs.modules;

/**
 * {@link IModulesServiceFactory} for Google AppEngine.
 *
 */
final class ModulesServiceFactoryImpl implements IModulesServiceFactory {
  @Override
  public ModulesService getModulesService() {
    return new ModulesServiceImpl();
  }
}
