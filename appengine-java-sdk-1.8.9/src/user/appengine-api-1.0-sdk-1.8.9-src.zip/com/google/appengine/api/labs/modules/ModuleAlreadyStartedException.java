package com.google.appengine.api.labs.modules;

/**
 * Thrown when an application tries to start a module that is already started.
 *
 * @see ModulesService#startModule
 */
@Deprecated
public class ModuleAlreadyStartedException extends ModulesException {

  ModuleAlreadyStartedException(String detail) {
    super(detail);
  }
}
