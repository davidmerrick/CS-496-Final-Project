package com.google.appengine.api.labs.modules;

/**
 * Thrown when an application tries to stop a module that is already stopped.
 *
 * @see ModulesService#stopModule
 */
@Deprecated
public class ModuleAlreadyStoppedException extends ModulesException {

  ModuleAlreadyStoppedException(String detail) {
    super(detail);
  }
}
