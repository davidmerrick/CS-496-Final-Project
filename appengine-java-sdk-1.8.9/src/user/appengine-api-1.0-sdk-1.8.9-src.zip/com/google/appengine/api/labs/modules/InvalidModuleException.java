package com.google.appengine.api.labs.modules;

/**
 * Exception thrown when the given module name is invalid.
 *
 */
@Deprecated
public class InvalidModuleException extends ModulesException {

  InvalidModuleException(String detail) {
    super(detail);
  }
}
