// Copyright 2012 Google Inc. All rights reserved.

package com.google.appengine.api.channel;

/**
 * Constructs and instance of the Channel service.
 *
 */
final class ChannelServiceFactoryImpl implements IChannelServiceFactory {

  @Override
  public ChannelService getChannelService() {
    return new ChannelServiceImpl();
  }

}
